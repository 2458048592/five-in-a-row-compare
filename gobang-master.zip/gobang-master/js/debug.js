var debug = {};
module.exports = debug;
